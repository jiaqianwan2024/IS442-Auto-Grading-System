/*
 * Name:
 * Email ID:
 */

import java.util.*;   

public class ShapeComparator{

    
}
